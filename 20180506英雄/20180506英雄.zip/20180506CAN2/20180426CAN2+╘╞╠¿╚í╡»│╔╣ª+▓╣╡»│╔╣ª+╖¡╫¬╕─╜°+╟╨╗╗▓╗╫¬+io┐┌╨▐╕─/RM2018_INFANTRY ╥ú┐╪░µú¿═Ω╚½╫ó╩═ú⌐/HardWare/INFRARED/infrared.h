#ifndef __INFRARED_H
#define __INFRARED_H	 
#include "stm32f4xx.h"



void Infrared_Configuration(void);

#endif

















