#ifndef __ControlTask_H
#define __ControlTask_H	

#include "main.h"

void WholeInitTask(void);
void Control_Task(void);
extern uint32_t time_tick_1ms;

#endif
