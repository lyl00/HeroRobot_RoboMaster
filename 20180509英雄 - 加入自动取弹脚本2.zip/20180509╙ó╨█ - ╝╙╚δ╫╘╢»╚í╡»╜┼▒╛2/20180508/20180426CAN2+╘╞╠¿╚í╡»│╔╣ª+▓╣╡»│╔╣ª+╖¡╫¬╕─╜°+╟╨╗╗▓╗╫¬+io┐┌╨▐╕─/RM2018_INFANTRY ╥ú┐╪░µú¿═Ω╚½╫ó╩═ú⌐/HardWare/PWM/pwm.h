#ifndef PWM_H
#define PWM_H
#include "stm32f4xx.h"
void TIM8_PWM_Init(u32 arr,u32 psc);
#endif




