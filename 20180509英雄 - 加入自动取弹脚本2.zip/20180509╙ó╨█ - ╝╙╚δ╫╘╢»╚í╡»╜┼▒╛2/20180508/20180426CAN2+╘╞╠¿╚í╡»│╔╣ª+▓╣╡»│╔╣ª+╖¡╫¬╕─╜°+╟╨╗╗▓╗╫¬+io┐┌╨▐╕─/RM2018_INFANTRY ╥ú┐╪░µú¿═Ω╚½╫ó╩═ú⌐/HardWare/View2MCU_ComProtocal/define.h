#ifndef _DEFINE_H
#define _DEFINE_H	
#define u8 unsigned char
#define u32 unsigned int
#define u16 unsigned short
#define s16 signed short
#endif 
