#ifndef __AutoAim
#define __AutoAim	
#include "main.h"

void Auto_aim(u8 *rx_buf,int len);

extern float view_ch2;
extern float view_ch3;

#endif
