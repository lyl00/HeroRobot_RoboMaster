#ifndef __DUCT_H__
#define __DUCT_H__
#include "stm32f4xx.h"

void Duct_Configuration(void);
void Duct_Loop(void);

#endif
