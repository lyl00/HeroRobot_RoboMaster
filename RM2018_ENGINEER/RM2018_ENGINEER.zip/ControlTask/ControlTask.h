#ifndef __ControlTask_H
#define __ControlTask_H	

#include "main.h"

extern float disp0[8];
extern int16_t disp1[8];

void WholeInitTask(void);
void Init_Task(void);
void Control_Task(void);


#endif
