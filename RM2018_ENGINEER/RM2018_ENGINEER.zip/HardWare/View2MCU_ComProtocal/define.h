#ifndef _DEFINE_H
#define _DEFINE_H	
typedef unsigned char 		u8;
typedef unsigned int		u32;
typedef unsigned short		u16;
typedef signed short		s16;
#endif 
